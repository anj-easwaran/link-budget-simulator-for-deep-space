# Deep-Space FSO Link Simulator (v2)

Clean, literature-grounded rebuild. Every formula is recorded in
`docs/equations.md` (statement, symbols, units, paper + equation number)
before it appears in code; nothing is tuned to match measured data.

## Run

Each script prints its results; the maths stays in `model/`:

```
PYTHONPATH=model python validation.py   # 65-check pass/fail suite (see kinds below)
python studies/station_scenarios.py     # the Surrey station table (Chapter 4)
python studies/inverse_solver.py        # what hardware closes a link into Surrey (uplink table)
python studies/stabilised_laser.py      # Objective 4: coherent/linewidth analysis
python model/terminal.py                # Objective 5: NODE component breakdown
```

## Modules

| File | Contents |
|---|---|
| `constants.py` / `utility.py` | exact SI constants; the only dB conversions |
| `geometry.py` | slant range, atmospheric path |
| `transmitter.py` / `receiver.py` | Klein & Degnan gains, divergence |
| `channel.py` | FSPL, Mie/Kim atmosphere, HV5/7 turbulence chain, background light |
| `pointing.py` | Gaussian/Airy pointing loss, optimum gain |
| `modulation.py` | OOK and exact M-PPM on the Poisson channel, PPM soft capacity |
| `coding.py` | SCPPM frame rates, capacity-gap closure test, rate search, flux needed for a rate |
| `coherent.py` | shot-noise-limited BPSK, phase-noise DPSK BER and rate (Kikuchi) |
| `link_budget.py` | the forward model: P_R, photon flux, margin, dB table |
| `missions.py` | DSOC, LLCD, GOPEX and Surrey ODK16 parameter sets, one citation per line |
| `terminal.py` | NODE mass/power component budget (Kingsbury 2015) |
| `validation.py` | the test suite |
| `studies/station_scenarios.py`, `inverse_solver.py` | the Surrey forward table and inverse (uplink/downlink) sizing |
| `studies/stabilised_laser.py` | Objective 4 comparison, printed |

## Validation kinds

- **reproduction** — reproduces a published computed table (validates the code)
- **measured** — against flight data (DSOC decode threshold within 0.75 dB;
  DSOC rate-vs-distance ratio; LLCD photon budget). Only these test physics
  against reality; they are built to cancel or bracket unpublished efficiencies.

## Uncertainty

Values marked ASSUMED carry (pessimistic, optimistic) intervals recorded
beside them in `missions.py`; outputs are bracketed by evaluating the model
at the two joint edges (interval propagation, `docs/equations.md` sec. 10).
Scenario printouts report these bounds alongside the nominal values.

## Style rules

Plain classes, no inheritance. `get_*` returns linear SI values; dB only in
`utility.py` and printed tables. Mission parameters one per line with source.
